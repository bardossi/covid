import { initForm } from './form.js';
import './styles.css';
import 'zizi-card';

document.addEventListener('DOMContentLoaded', () => {
    initForm();
})

console.log('hello');